# ESTATUS Backend

API compatible con el prototipo HTML (`window.ESTATUS_API`).

## Qué incluye

| Método | Ruta | Auth | Descripción |
|--------|------|------|-------------|
| POST | `/api/register` | no | Registro 18+ |
| POST | `/api/login` | no | Login |
| POST | `/api/logout` | sí | Cierra sesión (cliente borra token) |
| GET | `/api/me` | sí | Usuario actual |
| POST | `/api/verify-email` | no | Confirma correo con token |
| POST | `/api/resend-verification` | sí | Reenvía token (log en consola) |
| GET | `/api/wallet` | sí | Saldo + ledger |
| GET | `/api/orders` | sí | Órdenes de recarga |
| POST | `/api/topups` | sí | Inicia recarga (MP o fake) |
| POST | `/api/webhooks/mercadopago` | — | Webhook de pago |
| GET | `/api/profile/:username` | no | Perfil público |
| PUT | `/api/profile` | sí | Actualiza perfil |
| POST | `/api/profile/posts` | sí | Publica foto/video |
| DELETE | `/api/profile/posts/:id` | sí | Borra post |
| GET | `/api/admin/users` | admin | Lista usuarios |

La **primera cuenta registrada** recibe rol `superadmin` y **50 EST** de bienvenida.

## Arranque local

```bash
cd estatus-backend
cp .env.example .env
# Edita JWT_SECRET y CORS_ORIGIN (tu URL de Pages)
npm install
npm start
```

API en `http://localhost:8787`.

### Conectar el HTML

En el `index.html` (o un `config.js` cargado antes del script de API), define:

```html
<script>
  window.ESTATUS_API = 'http://localhost:8787';
  // en producción:
  // window.ESTATUS_API = 'https://tu-api.onrender.com';
</script>
```

Debe ir **antes** del bloque que empieza con `/* ESTATUS · conexión con el backend */`.

## Recargas

- Sin `MP_ACCESS_TOKEN`: responde `pagos_no_configurados`.
- Con `ALLOW_FAKE_TOPUP=1`: acredita créditos **sin cobro** (solo desarrollo).
- Con token de MercadoPago: crea preferencia de checkout y el webhook acredita al aprobar.

El front exige **correo verificado** antes de recargar. En local el token de verificación se imprime en la consola del servidor:

```
[verify-email] correo@ejemplo.com TOKEN
```

Ábrelo como: `https://tu-front.pages.dev?verificar=TOKEN`

## Deploy gratis (Render)

1. Sube esta carpeta a un repo GitHub.
2. [Render](https://render.com) → **New Web Service** → conecta el repo.
3. Build: `npm install`
4. Start: `npm start`
5. Variables de entorno: copia `.env.example`.
6. `CORS_ORIGIN` = tu URL de Cloudflare Pages.
7. Disco persistente (opcional): monta `/opt/render/project/src/data` para no perder la DB al reiniciar.

Para datos persistentes en Render free sin disco, migra luego a Postgres.

## Cloudflare Pages (front)

1. Sube `index.html`.
2. Añade al inicio del HTML (tras `<head>` o antes de los scripts de app):

```html
<script>window.ESTATUS_API='https://TU-SERVICIO.onrender.com';</script>
```

3. Redeploy del front.

## Seguridad (antes de producción real)

- Cambia `JWT_SECRET`.
- Restringe `CORS_ORIGIN` (sin `*`).
- No uses `ALLOW_FAKE_TOPUP` en producción.
- Configura correo real (Resend, SES, etc.) para verificación.
- Migra de JSON a Postgres si hay varios usuarios.
- Las fotos en base64 en JSON no escalan: usa R2/S3.
