const fs = require('fs');
const path = require('path');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'estatus.json');

const defaultDb = () => ({
  users: [],
  ledger: [],
  orders: [],
  profiles: {},
  emailTokens: [],
  meta: { version: 1 }
});

function ensure() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(defaultDb(), null, 2));
  }
}

function load() {
  ensure();
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf8');
    const data = JSON.parse(raw);
    if (!Array.isArray(data.users)) data.users = [];
    if (!Array.isArray(data.ledger)) data.ledger = [];
    if (!Array.isArray(data.orders)) data.orders = [];
    if (!data.profiles || typeof data.profiles !== 'object') data.profiles = {};
    if (!Array.isArray(data.emailTokens)) data.emailTokens = [];
    return data;
  } catch {
    return defaultDb();
  }
}

function save(data) {
  ensure();
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, DB_FILE);
}

function withDb(fn) {
  const data = load();
  const result = fn(data);
  save(data);
  return result;
}

module.exports = { load, save, withDb, DB_FILE };
