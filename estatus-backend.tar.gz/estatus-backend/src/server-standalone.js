#!/usr/bin/env node
/**
 * ESTATUS API — backend real sin dependencias npm
 * Compatible con window.ESTATUS_API del prototipo HTML
 *
 * Uso:
 *   PORT=8787 JWT_SECRET=secreto CORS_ORIGIN=* ALLOW_FAKE_TOPUP=1 node src/server-standalone.js
 */
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const PORT = Number(process.env.PORT || 8787);
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(24).toString('hex');
const CORS_ORIGIN = (process.env.CORS_ORIGIN || '*').split(',').map((s) => s.trim()).filter(Boolean);
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'estatus.json');
const ALLOW_FAKE_TOPUP = process.env.ALLOW_FAKE_TOPUP === '1';
const MP_ACCESS_TOKEN = process.env.MP_ACCESS_TOKEN || '';
const APP_URL = (process.env.APP_URL || '').replace(/\/$/, '');
const API_PUBLIC_URL = (process.env.API_PUBLIC_URL || '').replace(/\/$/, '');

const PACKAGES = {
  inicial: { credits: 100, price_mxn: 29 },
  plata: { credits: 550, price_mxn: 99 },
  oro: { credits: 1200, price_mxn: 199 },
  elite: { credits: 3300, price_mxn: 449 }
};

const attempts = new Map();

function ensureDb() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(
      DB_FILE,
      JSON.stringify({ users: [], ledger: [], orders: [], profiles: {}, emailTokens: [] }, null, 2)
    );
  }
}
function load() {
  ensureDb();
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } catch {
    return { users: [], ledger: [], orders: [], profiles: {}, emailTokens: [] };
  }
}
function save(data) {
  ensureDb();
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, DB_FILE);
}
function withDb(fn) {
  const data = load();
  const r = fn(data);
  save(data);
  return r;
}

function uuid() {
  return crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex');
}
function b64url(buf) {
  return Buffer.from(buf)
    .toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}
function signJwt(payload, days) {
  const header = b64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const body = Object.assign({}, payload, {
    exp: Math.floor(Date.now() / 1000) + (days || 14) * 86400
  });
  const mid = b64url(JSON.stringify(body));
  const sig = b64url(crypto.createHmac('sha256', JWT_SECRET).update(header + '.' + mid).digest());
  return header + '.' + mid + '.' + sig;
}
function verifyJwt(token) {
  const parts = String(token || '').split('.');
  if (parts.length !== 3) throw new Error('bad');
  const [h, m, s] = parts;
  const expect = b64url(crypto.createHmac('sha256', JWT_SECRET).update(h + '.' + m).digest());
  if (s !== expect) throw new Error('bad');
  const payload = JSON.parse(Buffer.from(m.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString());
  if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) throw new Error('exp');
  return payload;
}
function hashPassword(pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(pw, salt, 32).toString('hex');
  return salt + ':' + hash;
}
function checkPassword(pw, stored) {
  const [salt, hash] = String(stored || '').split(':');
  if (!salt || !hash) return false;
  const h = crypto.scryptSync(pw, salt, 32).toString('hex');
  try {
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(h, 'hex'));
  } catch {
    return false;
  }
}

function validUsername(u) {
  return typeof u === 'string' && /^[a-zA-Z0-9._-]{3,24}$/.test(u);
}
function validEmail(e) {
  return typeof e === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e) && e.length <= 120;
}
function validPassword(p) {
  return typeof p === 'string' && p.length >= 8 && p.length <= 128;
}
function isAdult(birth) {
  const b = new Date(birth);
  if (Number.isNaN(b.getTime())) return false;
  const n = new Date();
  let age = n.getFullYear() - b.getFullYear();
  const m = n.getMonth() - b.getMonth();
  if (m < 0 || (m === 0 && n.getDate() < b.getDate())) age--;
  return age >= 18 && age <= 120;
}
function tooMany(key, max, windowMs) {
  const now = Date.now();
  let row = attempts.get(key);
  if (!row || now > row.until) row = { n: 0, until: now + windowMs };
  row.n += 1;
  attempts.set(key, row);
  return row.n > max;
}
function balanceOf(data, userId) {
  return data.ledger.filter((x) => x.user_id === userId).reduce((s, x) => s + (x.delta || 0), 0);
}
function publicUser(u) {
  return {
    id: u.id,
    username: u.username,
    email: u.email,
    role: u.role || 'user',
    email_verified: !!u.email_verified,
    birth_date: u.birth_date,
    created_at: u.created_at
  };
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > 3_000_000) {
        reject(new Error('big'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch {
        resolve({});
      }
    });
    req.on('error', reject);
  });
}

function send(res, status, obj, origin) {
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': origin || '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
  };
  res.writeHead(status, headers);
  res.end(JSON.stringify(obj));
}
function err(res, status, code, origin) {
  send(res, status, { error: code }, origin);
}
function pickOrigin(req) {
  const o = req.headers.origin;
  if (!o) return CORS_ORIGIN[0] || '*';
  if (CORS_ORIGIN.includes('*') || CORS_ORIGIN.includes(o)) return o;
  return CORS_ORIGIN[0] || '*';
}

function authUser(req) {
  const h = req.headers.authorization || '';
  const m = h.match(/^Bearer\s+(.+)$/i);
  if (!m) return null;
  try {
    const payload = verifyJwt(m[1]);
    const data = load();
    const user = data.users.find((x) => x.id === payload.sub);
    if (!user || user.status === 'suspendido') return null;
    return user;
  } catch {
    return null;
  }
}

async function mpPreference(body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const req = https.request(
      {
        hostname: 'api.mercadopago.com',
        path: '/checkout/preferences',
        method: 'POST',
        headers: {
          Authorization: 'Bearer ' + MP_ACCESS_TOKEN,
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(data)
        }
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          try {
            resolve({ status: res.statusCode, json: JSON.parse(Buffer.concat(chunks).toString()) });
          } catch (e) {
            reject(e);
          }
        });
      }
    );
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

const server = http.createServer(async (req, res) => {
  const origin = pickOrigin(req);
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
    });
    return res.end();
  }

  const u = new URL(req.url, 'http://localhost');
  const p = u.pathname;
  const method = req.method || 'GET';

  try {
    if (method === 'GET' && (p === '/' || p === '/api/health')) {
      return send(res, 200, { ok: true, service: 'estatus-api', version: '1.0.0-standalone' }, origin);
    }

    // REGISTER
    if (method === 'POST' && p === '/api/register') {
      const body = await readBody(req);
      const username = String(body.username || '').trim();
      const email = String(body.email || '').trim().toLowerCase();
      const password = body.password;
      const birth_date = body.birth_date;
      if (!validUsername(username)) return err(res, 400, 'usuario_invalido', origin);
      if (!validEmail(email)) return err(res, 400, 'correo_invalido', origin);
      if (!validPassword(password)) return err(res, 400, 'contrasena_invalida', origin);
      if (!isAdult(birth_date)) return err(res, 400, 'edad_no_permitida', origin);
      if (!body.accept) return err(res, 400, 'debes_aceptar_terminos', origin);
      if (tooMany((req.socket.remoteAddress || '') + '|reg', 8, 15 * 60 * 1000)) {
        return err(res, 429, 'demasiados_intentos', origin);
      }
      let result;
      try {
        result = withDb((data) => {
          if (
            data.users.some(
              (x) => x.username.toLowerCase() === username.toLowerCase() || x.email === email
            )
          ) {
            const e = new Error('dup');
            e.code = 'usuario_o_correo_ya_registrado';
            throw e;
          }
          const isFirst = data.users.length === 0;
          const user = {
            id: uuid(),
            username,
            email,
            password_hash: hashPassword(password),
            birth_date,
            role: isFirst ? 'superadmin' : 'user',
            status: 'activo',
            email_verified: false,
            created_at: new Date().toISOString()
          };
          data.users.push(user);
          data.profiles[username] = { name: username, bio: '', photo: '', banner: '', frame: 0, posts: [] };
          data.ledger.push({
            id: uuid(),
            user_id: user.id,
            delta: 50,
            reason: 'bienvenida',
            created_at: new Date().toISOString()
          });
          const vtoken = uuid();
          data.emailTokens.push({ token: vtoken, user_id: user.id, exp: Date.now() + 48 * 3600 * 1000 });
          return { user, vtoken };
        });
      } catch (e) {
        if (e.code === 'usuario_o_correo_ya_registrado') {
          return err(res, 409, 'usuario_o_correo_ya_registrado', origin);
        }
        throw e;
      }
      console.log('[verify-email]', result.user.email, result.vtoken);
      const token = signJwt({ sub: result.user.id, username: result.user.username, role: result.user.role });
      return send(res, 200, { token, user: publicUser(result.user), email_sent: true }, origin);
    }

    // LOGIN
    if (method === 'POST' && p === '/api/login') {
      const body = await readBody(req);
      const userOrEmail = String(body.user || body.username || body.email || '').trim();
      const password = body.password;
      if (!userOrEmail || !password) return err(res, 400, 'credenciales_invalidas', origin);
      if (tooMany((req.socket.remoteAddress || '') + '|' + userOrEmail.toLowerCase(), 12, 15 * 60 * 1000)) {
        return err(res, 429, 'demasiados_intentos', origin);
      }
      const data = load();
      const user = data.users.find(
        (x) =>
          x.username.toLowerCase() === userOrEmail.toLowerCase() || x.email === userOrEmail.toLowerCase()
      );
      if (!user || !checkPassword(password, user.password_hash)) {
        return err(res, 401, 'credenciales_invalidas', origin);
      }
      if (user.status === 'suspendido') return err(res, 403, 'credenciales_invalidas', origin);
      const token = signJwt({ sub: user.id, username: user.username, role: user.role || 'user' });
      return send(res, 200, { token, user: publicUser(user) }, origin);
    }

    if (method === 'POST' && p === '/api/logout') {
      return send(res, 200, { ok: true }, origin);
    }

    if (method === 'GET' && p === '/api/me') {
      const user = authUser(req);
      if (!user) return err(res, 401, 'no_autenticado', origin);
      return send(res, 200, { user: publicUser(user) }, origin);
    }

    if (method === 'POST' && p === '/api/verify-email') {
      const body = await readBody(req);
      const token = String(body.token || '');
      if (!token) return err(res, 400, 'token_invalido_o_caducado', origin);
      try {
        withDb((data) => {
          const row = data.emailTokens.find((t) => t.token === token);
          if (!row || row.exp < Date.now()) throw Object.assign(new Error('bad'), { code: 'token_invalido_o_caducado' });
          const user = data.users.find((x) => x.id === row.user_id);
          if (!user) throw Object.assign(new Error('bad'), { code: 'token_invalido_o_caducado' });
          user.email_verified = true;
          data.emailTokens = data.emailTokens.filter((t) => t.token !== token);
        });
        return send(res, 200, { ok: true }, origin);
      } catch (e) {
        if (e.code === 'token_invalido_o_caducado') return err(res, 400, e.code, origin);
        throw e;
      }
    }

    if (method === 'POST' && p === '/api/resend-verification') {
      const user = authUser(req);
      if (!user) return err(res, 401, 'no_autenticado', origin);
      if (user.email_verified) return send(res, 200, { ok: true, already: true }, origin);
      if (tooMany((req.socket.remoteAddress || '') + '|resend', 5, 3600 * 1000)) {
        return err(res, 429, 'demasiados_envios', origin);
      }
      const token = uuid();
      withDb((data) => {
        data.emailTokens = data.emailTokens.filter((t) => t.user_id !== user.id);
        data.emailTokens.push({ token, user_id: user.id, exp: Date.now() + 48 * 3600 * 1000 });
      });
      console.log('[resend-verify]', user.email, token);
      return send(res, 200, { ok: true, email_sent: true }, origin);
    }

    if (method === 'GET' && p === '/api/wallet') {
      const user = authUser(req);
      if (!user) return err(res, 401, 'no_autenticado', origin);
      const data = load();
      const ledger = data.ledger
        .filter((x) => x.user_id === user.id)
        .sort((a, b) => (a.created_at < b.created_at ? 1 : -1))
        .slice(0, 50);
      return send(res, 200, { balance: balanceOf(data, user.id), ledger }, origin);
    }

    if (method === 'GET' && p === '/api/orders') {
      const user = authUser(req);
      if (!user) return err(res, 401, 'no_autenticado', origin);
      const data = load();
      const orders = data.orders
        .filter((x) => x.user_id === user.id)
        .sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
      return send(res, 200, { orders }, origin);
    }

    if (method === 'POST' && p === '/api/topups') {
      const user = authUser(req);
      if (!user) return err(res, 401, 'no_autenticado', origin);
      if (!user.email_verified) return err(res, 403, 'correo_no_verificado', origin);
      if (tooMany((req.socket.remoteAddress || '') + '|topup', 10, 3600 * 1000)) {
        return err(res, 429, 'demasiadas_recargas', origin);
      }
      const body = await readBody(req);
      const pkgName = String(body.package || '');
      const pkg = PACKAGES[pkgName];
      if (!pkg) return err(res, 400, 'pagos_no_configurados', origin);

      if (!MP_ACCESS_TOKEN) {
        if (!ALLOW_FAKE_TOPUP) return err(res, 503, 'pagos_no_configurados', origin);
        withDb((data) => {
          data.ledger.push({
            id: uuid(),
            user_id: user.id,
            delta: pkg.credits,
            reason: 'topup',
            created_at: new Date().toISOString()
          });
          data.orders.push({
            id: uuid(),
            user_id: user.id,
            package: pkgName,
            credits: pkg.credits,
            amount_mxn: pkg.price_mxn,
            status: 'paid',
            created_at: new Date().toISOString()
          });
        });
        return send(res, 200, { ok: true, fake: true, credits: pkg.credits }, origin);
      }

      const external_reference = uuid();
      withDb((data) => {
        data.orders.push({
          id: external_reference,
          user_id: user.id,
          package: pkgName,
          credits: pkg.credits,
          amount_mxn: pkg.price_mxn,
          status: 'pending',
          created_at: new Date().toISOString()
        });
      });
      const pref = {
        items: [
          {
            title: `ESTATUS · ${pkg.credits} créditos (${pkgName})`,
            quantity: 1,
            currency_id: 'MXN',
            unit_price: pkg.price_mxn
          }
        ],
        external_reference,
        back_urls: {
          success: `${APP_URL || 'https://example.com'}?pago=ok`,
          pending: `${APP_URL || 'https://example.com'}?pago=pendiente`,
          failure: `${APP_URL || 'https://example.com'}?pago=error`
        },
        auto_return: 'approved'
      };
      if (API_PUBLIC_URL) pref.notification_url = API_PUBLIC_URL + '/api/webhooks/mercadopago';
      const mp = await mpPreference(pref);
      if (!mp.json || !mp.json.init_point) return err(res, 503, 'pagos_no_configurados', origin);
      return send(res, 200, { checkout_url: mp.json.init_point, preference_id: mp.json.id }, origin);
    }

    // Profile
    if (method === 'GET' && p.startsWith('/api/profile/')) {
      const username = decodeURIComponent(p.slice('/api/profile/'.length));
      const data = load();
      const user = data.users.find((x) => x.username.toLowerCase() === username.toLowerCase());
      if (!user) return err(res, 404, 'no_encontrado', origin);
      const profile = data.profiles[user.username] || {
        name: user.username,
        bio: '',
        photo: '',
        banner: '',
        frame: 0,
        posts: []
      };
      return send(res, 200, { username: user.username, role: user.role || 'user', profile }, origin);
    }

    if (method === 'PUT' && p === '/api/profile') {
      const user = authUser(req);
      if (!user) return err(res, 401, 'no_autenticado', origin);
      const body = await readBody(req);
      withDb((data) => {
        const prev = data.profiles[user.username] || { posts: [] };
        data.profiles[user.username] = {
          name: String(body.name || user.username).trim().slice(0, 30) || user.username,
          bio: String(body.bio || '').slice(0, 280),
          frame: Math.max(0, Math.min(50, Number(body.frame) || 0)),
          photo:
            typeof body.photo === 'string' && body.photo.startsWith('data:image/')
              ? body.photo.slice(0, 900000)
              : prev.photo || '',
          banner:
            typeof body.banner === 'string' && body.banner.startsWith('data:image/')
              ? body.banner.slice(0, 1200000)
              : prev.banner || '',
          posts: Array.isArray(prev.posts) ? prev.posts : []
        };
      });
      return send(res, 200, { ok: true }, origin);
    }

    if (method === 'POST' && p === '/api/profile/posts') {
      const user = authUser(req);
      if (!user) return err(res, 401, 'no_autenticado', origin);
      const body = await readBody(req);
      const type = body.type === 'video' ? 'video' : 'photo';
      const src = String(body.src || '');
      if (!src.startsWith('data:')) return err(res, 400, 'archivo_invalido', origin);
      let posts;
      withDb((data) => {
        const prev = data.profiles[user.username] || {
          name: user.username,
          bio: '',
          photo: '',
          banner: '',
          frame: 0,
          posts: []
        };
        if (!Array.isArray(prev.posts)) prev.posts = [];
        prev.posts.unshift({ id: uuid(), type, src: src.slice(0, 2500000), ts: Date.now() });
        prev.posts = prev.posts.slice(0, 24);
        data.profiles[user.username] = prev;
        posts = prev.posts;
      });
      return send(res, 200, { ok: true, posts }, origin);
    }

    if (method === 'DELETE' && p.startsWith('/api/profile/posts/')) {
      const user = authUser(req);
      if (!user) return err(res, 401, 'no_autenticado', origin);
      const id = p.slice('/api/profile/posts/'.length);
      withDb((data) => {
        const prev = data.profiles[user.username];
        if (prev && Array.isArray(prev.posts)) prev.posts = prev.posts.filter((x) => x.id !== id);
      });
      return send(res, 200, { ok: true }, origin);
    }

    if (method === 'GET' && p === '/api/admin/users') {
      const user = authUser(req);
      if (!user || !['admin', 'superadmin'].includes(user.role)) return err(res, 403, 'no_autenticado', origin);
      const data = load();
      return send(
        res,
        200,
        {
          users: data.users.map((x) => ({
            id: x.id,
            username: x.username,
            email: x.email,
            role: x.role,
            status: x.status,
            email_verified: x.email_verified,
            created_at: x.created_at,
            balance: balanceOf(data, x.id)
          }))
        },
        origin
      );
    }

    return err(res, 404, 'no_encontrado', origin);
  } catch (e) {
    console.error(e);
    return err(res, 500, 'error', origin);
  }
});

server.listen(PORT, () => {
  console.log('ESTATUS API real (standalone) en http://0.0.0.0:' + PORT);
  console.log('ALLOW_FAKE_TOPUP=' + ALLOW_FAKE_TOPUP);
  console.log('CORS=' + CORS_ORIGIN.join(','));
});
