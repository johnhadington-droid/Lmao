try { require('dotenv').config(); } catch (_) {}
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
let uuidv4;
try {
  uuidv4 = require('uuid').v4;
} catch (_) {
  uuidv4 = () =>
    'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      const v = c === 'x' ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
}
const { load, withDb } = require('./db');

const app = express();
const PORT = process.env.PORT || 8787;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-change-me-' + Math.random().toString(36);
const CORS_ORIGIN = (process.env.CORS_ORIGIN || '*')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);

const PACKAGES = {
  inicial: { credits: 100, price_mxn: 29 },
  plata: { credits: 550, price_mxn: 99 },
  oro: { credits: 1200, price_mxn: 199 },
  elite: { credits: 3300, price_mxn: 449 }
};

const loginAttempts = new Map(); // ip|user -> { n, until }

app.set('trust proxy', 1);
app.use(express.json({ limit: '2mb' }));
app.use(
  cors({
    origin(origin, cb) {
      if (!origin || CORS_ORIGIN.includes('*') || CORS_ORIGIN.includes(origin)) {
        return cb(null, true);
      }
      return cb(null, false);
    },
    credentials: true
  })
);

function err(res, status, code) {
  return res.status(status).json({ error: code });
}

function publicUser(u) {
  return {
    id: u.id,
    username: u.username,
    email: u.email,
    role: u.role || 'user',
    email_verified: !!u.email_verified,
    birth_date: u.birth_date,
    created_at: u.created_at
  };
}

function signToken(u) {
  return jwt.sign(
    { sub: u.id, username: u.username, role: u.role || 'user' },
    JWT_SECRET,
    { expiresIn: '14d' }
  );
}

function auth(req, res, next) {
  const h = req.headers.authorization || '';
  const m = h.match(/^Bearer\s+(.+)$/i);
  if (!m) return err(res, 401, 'no_autenticado');
  try {
    const payload = jwt.verify(m[1], JWT_SECRET);
    const data = load();
    const user = data.users.find((x) => x.id === payload.sub);
    if (!user || user.status === 'suspendido') return err(res, 401, 'no_autenticado');
    req.user = user;
    req.token = m[1];
    next();
  } catch {
    return err(res, 401, 'no_autenticado');
  }
}

function validUsername(u) {
  return typeof u === 'string' && /^[a-zA-Z0-9._-]{3,24}$/.test(u);
}
function validEmail(e) {
  return typeof e === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e) && e.length <= 120;
}
function validPassword(p) {
  return typeof p === 'string' && p.length >= 8 && p.length <= 128;
}
function isAdult(birth) {
  const b = new Date(birth);
  if (Number.isNaN(b.getTime())) return false;
  const n = new Date();
  let age = n.getFullYear() - b.getFullYear();
  const m = n.getMonth() - b.getMonth();
  if (m < 0 || (m === 0 && n.getDate() < b.getDate())) age--;
  return age >= 18 && age <= 120;
}

function rateKey(req, extra) {
  return (req.ip || 'ip') + '|' + (extra || '');
}
function tooMany(key, max, windowMs) {
  const now = Date.now();
  let row = loginAttempts.get(key);
  if (!row || now > row.until) row = { n: 0, until: now + windowMs };
  row.n += 1;
  loginAttempts.set(key, row);
  return row.n > max;
}

function balanceOf(data, userId) {
  return data.ledger
    .filter((x) => x.user_id === userId)
    .reduce((s, x) => s + (x.delta || 0), 0);
}

// ---------- Health ----------
app.get('/', (_req, res) => {
  res.json({ ok: true, service: 'estatus-api', version: '1.0.0' });
});
app.get('/api/health', (_req, res) => {
  res.json({ ok: true });
});

// ---------- Auth ----------
app.post('/api/register', (req, res) => {
  const body = req.body || {};
  const username = String(body.username || '').trim();
  const email = String(body.email || '').trim().toLowerCase();
  const password = body.password;
  const birth_date = body.birth_date;
  const accept = !!body.accept;

  if (!validUsername(username)) return err(res, 400, 'usuario_invalido');
  if (!validEmail(email)) return err(res, 400, 'correo_invalido');
  if (!validPassword(password)) return err(res, 400, 'contrasena_invalida');
  if (!isAdult(birth_date)) return err(res, 400, 'edad_no_permitida');
  if (!accept) return err(res, 400, 'debes_aceptar_terminos');

  if (tooMany(rateKey(req, 'reg'), 8, 15 * 60 * 1000)) {
    return err(res, 429, 'demasiados_intentos');
  }

  try {
    const out = withDb((data) => {
      const exists = data.users.some(
        (u) => u.username.toLowerCase() === username.toLowerCase() || u.email === email
      );
      if (exists) {
        const e = new Error('dup');
        e.code = 'usuario_o_correo_ya_registrado';
        throw e;
      }
      const isFirst = data.users.length === 0;
      const user = {
        id: uuidv4(),
        username,
        email,
        password_hash: bcrypt.hashSync(password, 10),
        birth_date,
        role: isFirst ? 'superadmin' : 'user',
        status: 'activo',
        email_verified: false,
        created_at: new Date().toISOString()
      };
      data.users.push(user);
      data.profiles[user.username] = {
        name: username,
        bio: '',
        photo: '',
        banner: '',
        frame: 0,
        posts: []
      };
      // bienvenida demo: 50 EST
      data.ledger.push({
        id: uuidv4(),
        user_id: user.id,
        delta: 50,
        reason: 'bienvenida',
        created_at: new Date().toISOString()
      });
      const token = uuidv4();
      data.emailTokens.push({
        token,
        user_id: user.id,
        exp: Date.now() + 48 * 3600 * 1000
      });
      return { user, verifyToken: token };
    });

    // En producción: enviar correo con link APP_URL?verificar=token
    // Aquí devolvemos email_sent true; el token no se expone en prod.
    console.log('[verify-email]', out.user.email, out.verifyToken);

    const token = signToken(out.user);
    return res.json({
      token,
      user: publicUser(out.user),
      email_sent: true
    });
  } catch (e) {
    if (e.code === 'usuario_o_correo_ya_registrado') {
      return err(res, 409, 'usuario_o_correo_ya_registrado');
    }
    console.error(e);
    return err(res, 500, 'error');
  }
});

app.post('/api/login', (req, res) => {
  const body = req.body || {};
  const userOrEmail = String(body.user || body.username || body.email || '').trim();
  const password = body.password;
  if (!userOrEmail || !password) return err(res, 400, 'credenciales_invalidas');

  const key = rateKey(req, userOrEmail.toLowerCase());
  if (tooMany(key, 12, 15 * 60 * 1000)) return err(res, 429, 'demasiados_intentos');

  const data = load();
  const user = data.users.find(
    (u) =>
      u.username.toLowerCase() === userOrEmail.toLowerCase() ||
      u.email === userOrEmail.toLowerCase()
  );
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return err(res, 401, 'credenciales_invalidas');
  }
  if (user.status === 'suspendido') return err(res, 403, 'credenciales_invalidas');

  loginAttempts.delete(key);
  const token = signToken(user);
  return res.json({ token, user: publicUser(user) });
});

app.post('/api/logout', auth, (_req, res) => {
  // JWT stateless: el cliente borra el token
  res.json({ ok: true });
});

app.get('/api/me', auth, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

app.post('/api/verify-email', (req, res) => {
  const token = String((req.body && req.body.token) || '');
  if (!token) return err(res, 400, 'token_invalido_o_caducado');
  try {
    withDb((data) => {
      const row = data.emailTokens.find((t) => t.token === token);
      if (!row || row.exp < Date.now()) {
        const e = new Error('bad');
        e.code = 'token_invalido_o_caducado';
        throw e;
      }
      const user = data.users.find((u) => u.id === row.user_id);
      if (!user) {
        const e = new Error('bad');
        e.code = 'token_invalido_o_caducado';
        throw e;
      }
      user.email_verified = true;
      data.emailTokens = data.emailTokens.filter((t) => t.token !== token);
    });
    return res.json({ ok: true });
  } catch (e) {
    if (e.code === 'token_invalido_o_caducado') return err(res, 400, e.code);
    return err(res, 500, 'error');
  }
});

app.post('/api/resend-verification', auth, (req, res) => {
  if (req.user.email_verified) return res.json({ ok: true, already: true });
  if (tooMany(rateKey(req, 'resend'), 5, 60 * 60 * 1000)) {
    return err(res, 429, 'demasiados_envios');
  }
  const token = uuidv4();
  withDb((data) => {
    data.emailTokens = data.emailTokens.filter((t) => t.user_id !== req.user.id);
    data.emailTokens.push({
      token,
      user_id: req.user.id,
      exp: Date.now() + 48 * 3600 * 1000
    });
  });
  console.log('[resend-verify]', req.user.email, token);
  return res.json({ ok: true, email_sent: true });
});

// ---------- Wallet ----------
app.get('/api/wallet', auth, (req, res) => {
  const data = load();
  const ledger = data.ledger
    .filter((x) => x.user_id === req.user.id)
    .sort((a, b) => (a.created_at < b.created_at ? 1 : -1))
    .slice(0, 50);
  res.json({
    balance: balanceOf(data, req.user.id),
    ledger
  });
});

app.get('/api/orders', auth, (req, res) => {
  const data = load();
  const orders = data.orders
    .filter((x) => x.user_id === req.user.id)
    .sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
  res.json({ orders });
});

app.post('/api/topups', auth, async (req, res) => {
  if (!req.user.email_verified) return err(res, 403, 'correo_no_verificado');
  if (tooMany(rateKey(req, 'topup'), 10, 60 * 60 * 1000)) {
    return err(res, 429, 'demasiadas_recargas');
  }
  const pkgName = String((req.body && req.body.package) || '');
  const pkg = PACKAGES[pkgName];
  if (!pkg) return err(res, 400, 'pagos_no_configurados');

  const mpToken = process.env.MP_ACCESS_TOKEN;
  if (!mpToken) {
    // Modo desarrollo: acredita al instante sin cobro real
    if (process.env.ALLOW_FAKE_TOPUP === '1') {
      withDb((data) => {
        data.ledger.push({
          id: uuidv4(),
          user_id: req.user.id,
          delta: pkg.credits,
          reason: 'topup',
          created_at: new Date().toISOString()
        });
        data.orders.push({
          id: uuidv4(),
          user_id: req.user.id,
          package: pkgName,
          credits: pkg.credits,
          amount_mxn: pkg.price_mxn,
          status: 'paid',
          created_at: new Date().toISOString()
        });
      });
      return res.json({ ok: true, fake: true, credits: pkg.credits });
    }
    return err(res, 503, 'pagos_no_configurados');
  }

  // MercadoPago Checkout Preference (simplificado)
  try {
    const appUrl = (process.env.APP_URL || '').replace(/\/$/, '');
    const apiUrl = (process.env.API_PUBLIC_URL || '').replace(/\/$/, '');
    const external_reference = uuidv4();

    withDb((data) => {
      data.orders.push({
        id: external_reference,
        user_id: req.user.id,
        package: pkgName,
        credits: pkg.credits,
        amount_mxn: pkg.price_mxn,
        status: 'pending',
        created_at: new Date().toISOString()
      });
    });

    const prefBody = {
      items: [
        {
          title: `ESTATUS · ${pkg.credits} créditos (${pkgName})`,
          quantity: 1,
          currency_id: 'MXN',
          unit_price: pkg.price_mxn
        }
      ],
      external_reference,
      back_urls: {
        success: `${appUrl}?pago=ok`,
        pending: `${appUrl}?pago=pendiente`,
        failure: `${appUrl}?pago=error`
      },
      auto_return: 'approved',
      notification_url: apiUrl ? `${apiUrl}/api/webhooks/mercadopago` : undefined
    };

    const r = await fetch('https://api.mercadopago.com/checkout/preferences', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${mpToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(prefBody)
    });
    const j = await r.json();
    if (!r.ok || !j.init_point) {
      console.error('MP preference error', j);
      return err(res, 503, 'pagos_no_configurados');
    }
    return res.json({ checkout_url: j.init_point, preference_id: j.id });
  } catch (e) {
    console.error(e);
    return err(res, 503, 'pagos_no_configurados');
  }
});

// Webhook MP (acredita una sola vez)
app.post('/api/webhooks/mercadopago', async (req, res) => {
  try {
    const topic = req.query.topic || req.query.type || req.body?.type;
    const id = req.query['data.id'] || req.body?.data?.id;
    if (!id || !process.env.MP_ACCESS_TOKEN) return res.sendStatus(200);

    const r = await fetch(`https://api.mercadopago.com/v1/payments/${id}`, {
      headers: { Authorization: `Bearer ${process.env.MP_ACCESS_TOKEN}` }
    });
    const pay = await r.json();
    if (!r.ok) return res.sendStatus(200);

    if (pay.status === 'approved' && pay.external_reference) {
      withDb((data) => {
        const order = data.orders.find((o) => o.id === pay.external_reference);
        if (!order || order.status === 'paid') return;
        order.status = 'paid';
        order.mp_payment_id = String(pay.id);
        data.ledger.push({
          id: uuidv4(),
          user_id: order.user_id,
          delta: order.credits,
          reason: 'topup',
          created_at: new Date().toISOString()
        });
      });
    }
    res.sendStatus(200);
  } catch (e) {
    console.error(e);
    res.sendStatus(200);
  }
});

// ---------- Profiles (multi-dispositivo) ----------
app.get('/api/profile/:username', (req, res) => {
  const data = load();
  const username = String(req.params.username || '');
  const user = data.users.find((u) => u.username.toLowerCase() === username.toLowerCase());
  if (!user) return err(res, 404, 'no_encontrado');
  const profile = data.profiles[user.username] || {
    name: user.username,
    bio: '',
    photo: '',
    banner: '',
    frame: 0,
    posts: []
  };
  res.json({
    username: user.username,
    role: user.role || 'user',
    profile
  });
});

app.put('/api/profile', auth, (req, res) => {
  const body = req.body || {};
  const name = String(body.name || req.user.username).trim().slice(0, 30);
  const bio = String(body.bio || '').slice(0, 280);
  const frame = Number.isFinite(+body.frame) ? Math.max(0, Math.min(50, +body.frame)) : 0;
  const photo = typeof body.photo === 'string' && body.photo.startsWith('data:image/')
    ? body.photo.slice(0, 900_000)
    : '';
  const banner = typeof body.banner === 'string' && body.banner.startsWith('data:image/')
    ? body.banner.slice(0, 1_200_000)
    : '';

  withDb((data) => {
    const prev = data.profiles[req.user.username] || { posts: [] };
    data.profiles[req.user.username] = {
      name: name.length >= 2 ? name : req.user.username,
      bio,
      frame,
      photo: photo || prev.photo || '',
      banner: banner || prev.banner || '',
      posts: Array.isArray(prev.posts) ? prev.posts : []
    };
  });
  res.json({ ok: true });
});

app.post('/api/profile/posts', auth, (req, res) => {
  const body = req.body || {};
  const type = body.type === 'video' ? 'video' : 'photo';
  const src = String(body.src || '');
  if (!src.startsWith('data:')) return err(res, 400, 'archivo_invalido');
  if (src.length > 2_500_000) return err(res, 400, 'archivo_grande');

  let posts;
  withDb((data) => {
    const prev = data.profiles[req.user.username] || {
      name: req.user.username,
      bio: '',
      photo: '',
      banner: '',
      frame: 0,
      posts: []
    };
    if (!Array.isArray(prev.posts)) prev.posts = [];
    prev.posts.unshift({
      id: uuidv4(),
      type,
      src,
      ts: Date.now()
    });
    prev.posts = prev.posts.slice(0, 24);
    data.profiles[req.user.username] = prev;
    posts = prev.posts;
  });
  res.json({ ok: true, posts });
});

app.delete('/api/profile/posts/:id', auth, (req, res) => {
  withDb((data) => {
    const prev = data.profiles[req.user.username];
    if (!prev || !Array.isArray(prev.posts)) return;
    prev.posts = prev.posts.filter((p) => p.id !== req.params.id);
  });
  res.json({ ok: true });
});

// ---------- Admin mínimo ----------
app.get('/api/admin/users', auth, (req, res) => {
  if (!['admin', 'superadmin'].includes(req.user.role)) return err(res, 403, 'no_autenticado');
  const data = load();
  res.json({
    users: data.users.map((u) => ({
      id: u.id,
      username: u.username,
      email: u.email,
      role: u.role,
      status: u.status,
      email_verified: u.email_verified,
      created_at: u.created_at,
      balance: balanceOf(data, u.id)
    }))
  });
});

app.listen(PORT, () => {
  console.log(`ESTATUS API en http://localhost:${PORT}`);
  console.log(`CORS: ${CORS_ORIGIN.join(', ')}`);
});
